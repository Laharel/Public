from django.apps import AppConfig


class BooksAuthorsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'books_authors_app'
